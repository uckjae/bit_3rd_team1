package ncontroller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import dao.NoticeDao;
import vo.Notice;

@Controller
@RequestMapping("/customer/")
public class CustomerController {

   private NoticeDao noticedao;

   @Autowired
   public void setNoticedao(NoticeDao noticedao) {
      this.noticedao = noticedao;
   }
   /*
       메소드의 리턴 타입이 [String]이면 [리턴 값]은 [뷰 이름]으로 사용된다
     View 에 데이터 전달 위해 Model interface 사용
     Model model > 함수의 parameter 사용시 자동 객체 생성  > Spring에서
     -> 이걸 통해서 데이터를 넣어줄 수 있음! ModelAndView에서 addObject의 역할을 한다고 생각하면 됨 
          대신 view 설정은 String을 return 해줘서 사용 가능!
     

    */
   // 글 목록 보기
   @RequestMapping("notice.htm")
   public String notices(String pg, String f, String q, Model model) {

      // 디폴트값
      int page = 1;
      String field = "TITLE";
      String query = "%%";

      // 조건처리
      if (pg != null && !pg.equals("")) {
         page = Integer.parseInt(pg);
      }
      if (f != null && !f.equals("")) {
         field = f;
      }
      if (q != null && !q.equals("")) {
         query = q;
      }
      
      //DAO 연결 > 데이터 받아오기
      List<Notice> list = null;
      try {
         list = noticedao.getNotices(page, field, query);
      } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      model.addAttribute("list",list); //view까지 전달됨(forward)
      return "notice.jsp";
   }
   
   //디테일 페이지로 넘어가기
   @RequestMapping("noticeDetail.htm")
   public String noticeDetail(String seq, Model model) {
      Notice notice = null;
      try {
         notice = noticedao.getNotice(seq);
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }
      model.addAttribute("notice",notice);
      return "noticeDetail.jsp";
   }
   
   //글쓰기 화면 처리 처리   
   @RequestMapping(value ="noticeReg.htm", method=RequestMethod.GET)
   public String form() {
      return "noticeReg.jsp";
   }
   
   //글쓰기 처리 (파일 업로드 필요)
   @RequestMapping(value ="noticeReg.htm", method=RequestMethod.POST)
   public String submit(Notice notice, HttpServletRequest request) {
            
      String filename = notice.getFile().getOriginalFilename();
      String path = request.getServletContext().getRealPath("/customer/upload"); //실제 realPath 뽑기
      
      String fpath = path + "\\" + filename; //경로 잡아주기! C:\\SmartWeb\... upload\a.jpg
      
      //실제 파일 쓰기!
      FileOutputStream fs = null;
      try {
         fs = new FileOutputStream(fpath); //파일 생성
         fs.write(notice.getFile().getBytes()); //바이트를 넣어서 파일을 읽음
         fs.close();
      }catch(Exception e) {
         System.out.println(e.getMessage());
      }
      
      notice.setFileSrc(filename);
      //DB처리
      try {
         noticedao.insert(notice);
      } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      
      return "redirect:notice.htm";
   }
   
   
   //글 삭제하기(noticeDel.htm) : 파라미터로 seq 받기!
   //return "redirect:notice.htm"
   @RequestMapping("noticeDel.htm")
   public String noticeDel(String seq) {
      
      try {
         noticedao.delete(seq);
      } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      return "redirect:notice.htm";
   }
   
   
   //글 수정하기(화면 처리 : select ... where seq=?) -> GET 방식임에도 불구하고 데이터를 처리해야 함
   //noticedao.getNotice(seq)
   //parameter에 model 받아서 필요한 데이터를 저장해보기 -> 화면에 데이터 출력해야 함 -> noticeEdit.jsp
   
   @RequestMapping(value ="noticeEdit.htm", method=RequestMethod.GET)
   public String noticeEdit(String seq, Model model) {
      Notice notice = null;
      try {
         notice = noticedao.getNotice(seq);
      } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      model.addAttribute("notice",notice);
      return "noticeEdit.jsp";
      
   }
   //실제 글 수정 처리하는 곳 (실update) -> update where seq=? POST 방식으로 처리
   //parameter로 notice를 가져옴 >> insert와 동일
   //return "redirect:noticeDetail.htm?seq="+notice.getSeq()
   
   @RequestMapping(value ="noticeEdit.htm", method=RequestMethod.POST)
   public String noticeEditProc(Notice notice, HttpServletRequest request, Model model) {
      
      String filename = notice.getFile().getOriginalFilename();
      String path = request.getServletContext().getRealPath("/customer/upload"); //실제 realPath 뽑기
      
      String fpath = path + "\\" + filename; //경로 잡아주기! C:\\SmartWeb\... upload\a.jpg
      
      //실제 파일 쓰기!
      FileOutputStream fs = null;
      try {
         fs = new FileOutputStream(fpath); //파일 생성
         fs.write(notice.getFile().getBytes()); //바이트를 넣어서 파일을 읽음
         fs.close();
      }catch(Exception e) {
         System.out.println(e.getMessage());
      }
      
      notice.setFileSrc(filename);
      //DB처리
      try {
        noticedao.update(notice);
      } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      
      return "redirect:noticeDetail.htm?seq="+notice.getSeq();
   }
   
   

   
   
   
   
   

}