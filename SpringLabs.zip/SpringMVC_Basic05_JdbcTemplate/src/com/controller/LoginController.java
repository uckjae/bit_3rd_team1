package com.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.MemberDAO;

/*
 *  로그인 화면 : GET 요청 > loginForm
 *  로그인 처리 : POST 요청 > id, pwd > memberCheck 검증 > loginSuccess(빈페이지)
 *  
 *  조건 : 인증 성공하면 session 담기 > [기존 servlet 과 동일]
 * 
 *  public void test(HttpSession session){
 *    session.setAttribute("USERID", "hong")
 *  }
 * 
 */
@Controller
@RequestMapping("/login.do")
public class LoginController {
   
	//GET 로그인 화면
	//POST:
	//session.setAttribute("userid,id)
	//membercheckDAO 함수 .. TRUE>loginSuccess
	                       //false >loginForm
	
	private MemberDAO memberdao;

	public MemberDAO getMemdao() {
		return memberdao;
	}

	public void setMemdao(MemberDAO memberdao) {
		this.memberdao = memberdao;
	}
	
	@Autowired
	public void getMemDao(MemberDAO memberdao) {
		this.memberdao = memberdao;
	}
	@RequestMapping(method=RequestMethod.GET)
	public String form() {
		return "loginForm";
	}
	@RequestMapping(method = RequestMethod.POST)
	public String Check(String id,String pwd,HttpSession session) throws SQLException {
	      
	      boolean checkok = memberdao.memberCheck(id, pwd);
	      
	      String view = null;
	      if(checkok) {
	         view = "loginSuccess";
	         session.setAttribute("USERID", id);
	      }else {
	         view = "loginForm";
	      }
	      
	      return view;
	   }

}











