package com.aopEx;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		
		//bean을 설정한 xml파일이 있는 위치를 지정하여 설정파일을 얻어옴
		AbstractApplicationContext ctx = 
				new GenericXmlApplicationContext("classpath:applicationCtx.xml");
		             //xml을 로딩하는 컨테이너
		
		//설정파일에서 bean을 가져옴
		
		Cats myCat = ctx.getBean("myCat",Cats.class); //속성명:myCat, 값:Cat클래스
		                                              //데이터를 담는 cat.class를 가져옴
		
		myCat.getCatsInfo(); //cat 메소드에 있는 getCatsInfo형태로 출력
	}
}
