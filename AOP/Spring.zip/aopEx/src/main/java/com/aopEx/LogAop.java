package com.aopEx;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;

public class LogAop {

	public Object loggerAop(JoinPoint joinpoint) throws Throwable{
		//around만 ProceedingJoinPoint사용 왜냐하면proceed()필요하기 때문 , 나머지는JoinPoint
		//JoinPoint객체를 사용하기 위해서는 JoinPoint를 어드바이스 메소드 매개변수로 선언만하면가능
		//그러면 클라이언트가 메소드호출시 ,스프링컨테이너가 JoinPoint객체를 생성
		
		//공통 기능이 적용되는 메서드가 어떤 메서드인지 출력하기 위해 메서드명을 얻어옴
		String signatureStr = joinpoint.getSignature().toShortString();
		//getSignature():클라이언트가 호출한 메소드정보가 저장된 Signature객체리턴
		//toShortString: 클라이언트가 호출한 메소드 Signature를 축약한 믄자열로 리턴
		System.out.println(signatureStr + "시작"); //메서드 실행
		
		//공통기능
		System.out.println("핵심 기능 전에 실행 할 공통 기능입니다. "+System.currentTimeMillis());
		
		try {
			Object obj = joinpoint.getSignature(); //핵심 기능 실행
			return obj;
		} finally {
			//공통기능
			System.out.println("핵심 기능 후에 실행 할 공통 기능입니다. "+System.currentTimeMillis());
			
			System.out.println(signatureStr + "끝");
		}
	}
}
